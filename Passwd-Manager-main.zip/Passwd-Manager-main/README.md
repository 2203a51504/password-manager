# BEEP! - Passwd-Manager
### [Click here to view](https://passwdmanager.herokuapp.com/) 👈


## Step 1: Installation

```console
# clone the repo
$ git clone https://github.com/Ak500k/Passwd-Manager.git
# change the working directory to Passwd-Manager
$ cd Passwd-Manager

# install the requirements
$ python3 -m pip install -r requirements.txt
```


## Step 2: 
```
# First execute run.py // This will start the local host
$ python3 run.py
```
## Step 3: 
```
Go to local host @ (localhost:8000/home)
```



# Join our Community:: 
<a href="https://telegram.me/+cEvv7j4re49jNGZl">
    <img width="80px" src="https://www.vectorlogo.zone/logos/telegram/telegram-icon.svg" /></a>&ensp;&nbsp;&nbsp;
    <a href="https://www.instagram.com/geeky.ak/">
    <img width="80px" src="https://www.vectorlogo.zone/logos/instagram/instagram-icon.svg" />

<br>
    
<br><a href="https://ko-fi.com/geekyak" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>
